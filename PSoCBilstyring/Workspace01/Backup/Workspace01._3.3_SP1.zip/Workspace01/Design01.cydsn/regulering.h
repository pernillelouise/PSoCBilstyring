// Function declarations
    extern int distanceFlag;
    int Regulering(int x);
    int start_right(unsigned int regulering);
    int start_left(unsigned int regulering);
    int stop();
    int direction(int dir);
    float convertVtoSpeed();
    int regulatePWM(int, int);
    int regulateDistance(int, int);
/* [] END OF FILE */
